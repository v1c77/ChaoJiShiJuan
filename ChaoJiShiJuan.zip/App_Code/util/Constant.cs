﻿/// <summary>
//常量类
/// </summary>
public class Constant
{
    //验证码
    public static readonly string CheckCode = "checkcode";
    //用户
    public static readonly string User= "user";   
    //成绩ID
    public static readonly string ScoreID = "scoreid";
}
