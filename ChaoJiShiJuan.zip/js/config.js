﻿var config = {
    
    img: {
        css: "imgchange",
        loadStyle: "3px solid #EDF3FF",
        changeStyle: "3px solid #F37E03"
    },
    table: {
        //间隔变色
        separateClass: "separate",
        separateStyle: "#F9F9F9",
        backStyle: "",
        //鼠标移动变色
        hoverStyle: "#f5f5f5"
    }
};